﻿#include"Graphics.h"

GraphicsEngine::GraphicsEngine(std::shared_ptr<Shader> shader /*= nullptr*/,
	std::shared_ptr<Shader>m_Tshader /*= nullptr*/):
	m_shader(shader),
	m_PickShader(m_Tshader)
{

}
unsigned int GraphicsEngine::LoadTexture(char const* path)
{
	return 1;
}


void GraphicsEngine::SetModelData(const ModelData & datas)
{
	 m_Vertices = std::get<0>(datas);
	m_Indices = std::get<1>(datas);;
}
void GraphicsEngine::SetViewSize(int width,int height)
{
	m_Width = width;
	m_Height = height;
}
void GraphicsEngine::UseShader()
{
	glUseProgram(m_shader->ShaderPromger);

}
