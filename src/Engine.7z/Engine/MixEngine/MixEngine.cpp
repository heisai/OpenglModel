﻿#include"MixEngine.h"
#define STB_IMAGE_IMPLEMENTATION
#include"../stb_image.h"
MixEngine::MixEngine(std::shared_ptr<Shader> shader):
	GraphicsEngine(shader)
{





}
void MixEngine::Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection)
{
	//设置顶点属性指针

    m_shader->setMat4("view", view);
    m_shader->setMat4("projection", projection);
    // glStencilMask(0x00);
    glBindVertexArray(m_VAO);
    glBindTexture(GL_TEXTURE_2D, transparentTexture);


    std::vector<glm::vec3> windows
        {
            glm::vec3(-1.5f, 0.0f, -0.48f),
            glm::vec3( 1.5f, 0.0f, 0.51f),
            glm::vec3( 2.0f, 0.0f, 0.7f),
            glm::vec3(-0.3f, 0.0f, -1.3f),
            glm::vec3( 1.5f, 0.0f, -1.0f)
        };
    for(auto vec: windows)
    {
        model = glm::translate(model, vec);
        m_shader->setMat4("model", model);
        glDrawArrays(GL_TRIANGLES, 0, 6);
    }



}

void MixEngine::InitBufferData()
{
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	// 顶点数组对象
	glGenVertexArrays(1, &m_VAO);
	//顶点缓冲对象
	glGenBuffers(1, &m_VBO);
	//绑定VAO
	glBindVertexArray(m_VAO);
	//把顶点数组复制到缓冲中供OpenGL使用
	glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
	glBufferData(GL_ARRAY_BUFFER, m_Vertice.size() * sizeof(float), &(m_Vertice[0]), GL_STATIC_DRAW);

	//设置顶点属性指针
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));

    std::string filename = Utils::GlslAbsolute("grass.png", "MixEngine");
    transparentTexture = LoadTexture(filename.c_str());


	
}

unsigned int  MixEngine::LoadTexture(char const* path)
{
#if 1
    unsigned int textureID;
    glGenTextures(1, &textureID);

    int width, height, nrComponents;
    unsigned char *data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data)
    {
        GLenum format;
        if (nrComponents == 1)
            format = GL_RED;
        else if (nrComponents == 3)
            format = GL_RGB;
        else if (nrComponents == 4)
            format = GL_RGBA;

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, format == GL_RGBA ? GL_CLAMP_TO_EDGE : GL_REPEAT); // for this tutorial: use GL_CLAMP_TO_EDGE to prevent semi-transparent borders. Due to interpolation it takes texels from next repeat
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, format == GL_RGBA ? GL_CLAMP_TO_EDGE : GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        stbi_image_free(data);
   }
#endif

        return textureID;
}

