﻿#pragma once
#include"../Graphics.h"
class MixEngine : public GraphicsEngine
{
public:
    MixEngine(std::shared_ptr<Shader> shader = nullptr);
	void Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection) override;
    void InitBufferData() override;

    unsigned int  LoadTexture(char const* path);
	
private:
    std::vector<float> m_Vertice = {
        // positions         // texture Coords (swapped y coordinates because texture is flipped upside down)
        0.0f,  0.5f,  0.0f,  0.0f,  0.0f,
        0.0f, -0.5f,  0.0f,  0.0f,  1.0f,
        1.0f, -0.5f,  0.0f,  1.0f,  1.0f,

        0.0f,  0.5f,  0.0f,  0.0f,  0.0f,
        1.0f, -0.5f,  0.0f,  1.0f,  1.0f,
        1.0f,  0.5f,  0.0f,  1.0f,  0.0f
    };
    unsigned int transparentTexture;
};
