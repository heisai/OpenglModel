#ifndef GRAPHICSENGINE_H
#define GRAPHICSENGINE_H
#include<iostream>
#include<filesystem>
#include<vector>
#include<memory>
#include<tuple>
// // #define STB_IMAGE_IMPLEMENTATION

#include"Shader.h"


/*
    1: 图形引擎基类
    2: Draw: 采用多态机制 运行时绑定
*/
struct ModelDataInfo
{
    std::vector<float> m_Vertices;
    std::vector<float>m_Indices;
};
using ModelData = std::tuple<std::vector<float>, std::vector<unsigned int>>;
class GraphicsEngine
{
public:
    GraphicsEngine(std::shared_ptr<Shader> shader = nullptr, std::shared_ptr<Shader>m_Stencilshader = nullptr);
    virtual void Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection) = 0;
    virtual void InitBufferData() = 0;
    virtual unsigned int LoadTexture(char const* path);
    virtual void SetModelData(const ModelData& datas);
    virtual void PickModel(glm::mat4 model, glm::mat4 view, glm::mat4 projection, int xpos, int ypos,int objetc_id)
    {

    }
    virtual void SetViewSize(int width, int height);
    void UseShader();

    /*virtual ~ GraphicsEngine();*/
public:
     unsigned int m_VBO, m_VAO, m_EBO;
     unsigned int m_Texture, m_Texture1, m_Texture2;
     unsigned int m_PickFBO;
     unsigned int m_PickTexture;
     unsigned int m_PickTexture1;
     unsigned int m_PickRBO;


     std::shared_ptr<Shader>m_shader;
     std::shared_ptr<Shader>m_PickShader;
	 std::vector<float> m_Vertices;
	 std::vector<unsigned int>m_Indices;
     int m_Width, m_Height;
};
#endif //GRAPHICSENGINE_H
