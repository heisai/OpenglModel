#include"LoadModelEngine.h"

LoadModelEngine::LoadModelEngine(std::shared_ptr<Shader> shader /*= nullptr*/):GraphicsEngine(shader)
{


}

void LoadModelEngine::Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection)
{
	m_shader->setMat4("model", model);
	m_shader->setMat4("view", view);
	m_shader->setMat4("projection", projection);
	m_OurModel->Draw((*m_shader.get()));
}

void LoadModelEngine::InitBufferData()
{
    std::string filename = Utils::GlslAbsolute("nanosuit.obj", "LoadModel");
    m_OurModel = std::make_shared<Model>(filename);
}
