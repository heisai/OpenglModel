#pragma once
#include"../Graphics.h"
#include"Model.h"
class LoadModelEngine : public GraphicsEngine
{
public:
	LoadModelEngine(std::shared_ptr<Shader> shader = nullptr);
	void Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection) override;
	void InitBufferData() override;

private:
	std::shared_ptr<Model>m_OurModel;
	


};
