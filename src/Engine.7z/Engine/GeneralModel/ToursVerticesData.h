#pragma once
#include "../Graphics.h"
class ToursVerticesData  final
{
public:
    ToursVerticesData() = default;
    ~ToursVerticesData() = default;
    ModelData GetModelDatas();
private:
    std::vector<float> GenerateCylinderVertices(float radius, float height, int sectors);
    std::vector<unsigned int> GenerateCylinderIndices(int sectors);

    std::vector<float> GenerateTorusVertices(float majorRadius = 1.0f,
        float minorRadius = 0.4f,
        unsigned int majorSegments = 32,
        unsigned int minorSegments = 16);
    std::vector<unsigned int> GenerateTorusIndices(unsigned int majorSegments = 32,
        unsigned int minorSegments = 16);
};
