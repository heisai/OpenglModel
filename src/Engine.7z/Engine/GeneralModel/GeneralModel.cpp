#include"GeneralModel.h"
GeneralModel::GeneralModel(std::shared_ptr<Shader> shader /*= nullptr*/):
    GraphicsEngine(shader),
	m_RayTrack(false)
{
	// ʹ��ʰȡ��ɫ��
	m_PickShader = std::make_shared<Shader>("pick_vertex.vs", "pick_fragment.fs", "GeneralModel");

}


void GeneralModel::Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection)
{
	m_shader->setMat4("projection", projection);
	m_shader->setMat4("view", view);
	m_shader->setMat4("model", model);

	//glStencilFunc(GL_ALWAYS, 1, 0xFF);
	//glStencilMask(0xFF);
	//���ù�Դ����
	m_shader->setVec3("viewPos", view[3]);
	m_shader->setVec3("light.positiom", 1.2f, 1.0f, 2.0f);
	m_shader->setVec3("light.ambient", 0.2f, 0.2f, 0.2f);
	m_shader->setVec3("light.diffuse", 0.5f, 0.5f, 0.5f);
	m_shader->setVec3("light.specular", 1.0f, 1.0f, 1.0f);
	//���ò�������
	m_shader->setVec3("material.ambient", 1.2f, 1.0f, 2.0f);
	m_shader->setVec3("material.diffuse", 0.2f, 0.2f, 0.2f);
	m_shader->setVec3("material.specular", 0.5f, 0.5f, 0.5f);
	m_shader->setFloat("material.shininess", 32.0f);
	//���ö�������ָ��
	glBindVertexArray(m_VAO);
	glDrawElements(GL_TRIANGLES, m_Indices.size(), GL_UNSIGNED_INT, 0);
}

void GeneralModel::InitBufferData()
{


	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	// �����������
	glGenVertexArrays(1, &m_VAO);
	//��VAO
	glBindVertexArray(m_VAO);

	//�Ѷ������鸴�Ƶ������й�OpenGLʹ��
	glGenBuffers(1, &m_VBO);
	glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
	glBufferData(GL_ARRAY_BUFFER, m_Vertices.size() * sizeof(float), m_Vertices.data(), GL_STATIC_DRAW);


	glGenBuffers(1, &m_EBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, m_Indices.size() * sizeof(unsigned int), m_Indices.data(), GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	//glBindFramebuffer(GL_FRAMEBUFFER, 0);
#if 1
	//glBindVertexArray(0);
	//������Ⱦ
	glGenFramebuffers(1, &m_PickFBO);
	glBindFramebuffer(GL_FRAMEBUFFER, m_PickFBO);
	

	// ����ʰȡ����

	glGenTextures(1, &m_PickTexture);
	glBindTexture(GL_TEXTURE_2D, m_PickTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, m_Width, m_Height, 0, GL_RGB, GL_UNSIGNED_BYTE, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	// ����������FBO
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, m_PickTexture, 0);

	// ������Ⱦ���������Ⱥ�ģ�壩
	glGenRenderbuffers(1, &m_PickRBO);
	glBindRenderbuffer(GL_RENDERBUFFER, m_PickRBO);
	glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, m_Width, m_Height);
	glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, m_PickRBO);

	// ���FBO
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	glBindTexture(GL_TEXTURE_2D, 0);
	glBindRenderbuffer(GL_RENDERBUFFER, 0);

	//// ���û��ƻ�����
	//GLenum drawBuffers[] = { GL_COLOR_ATTACHMENT0 };
	//glDrawBuffers(1, drawBuffers);



	std::cout << "FBO initialization completed" << std::endl;

#endif
}

void GeneralModel::SetLightColor(glm::vec3 lightcolor)
{
	m_LightColor = lightcolor;
}

void GeneralModel::SetObjectColor(glm::vec3 objectcolor)
{
	m_ObjectColor = objectcolor;
}

void GeneralModel::DrawStencil(glm::mat4 model, glm::mat4 view, glm::mat4 projection)
{
#if 0
	
	glStencilFunc(GL_NOTEQUAL, 1, 0xFF);
	glStencilMask(0x00);
	glDisable(GL_DEPTH_TEST);
	m_Stencilshader->UseProgram();
	float scale = 1.025f;
	model = glm::scale(model, glm::vec3(scale, scale, scale));
	m_Stencilshader->setMat4("model", model);
	m_Stencilshader->setMat4("view", view);
	m_Stencilshader->setMat4("projection", projection);
	glBindVertexArray(m_VAO);
	glDrawArrays(GL_TRIANGLES, 0, 36);
	glStencilMask(0xFF);
	glStencilFunc(GL_ALWAYS, 0, 0xFF);
	glEnable(GL_DEPTH_TEST);
#endif 
}

void GeneralModel::PickModel(glm::mat4 model, glm::mat4 view, glm::mat4 projection, int readX, int readY, 
	int objetc_id)
{



	std::cout << "========================== START PICKING =======================" << std::endl;
	std::cout << "Object ID: " << objetc_id << std::endl;
	std::cout << "Read coordinates: " << readX << ", " << readY << std::endl;
	std::cout << "FBO size: " << m_Width << " x " << m_Height << std::endl;

	// ���浱ǰ״̬
	GLint currentFBO;
	glGetIntegerv(GL_FRAMEBUFFER, &currentFBO);
	GLint currentReadBuffer;
	glGetIntegerv(GL_READ_BUFFER, &currentReadBuffer);

	

	glBindFramebuffer(GL_FRAMEBUFFER, m_PickFBO);
	glViewport(0, 0, m_Width, m_Height);
	std::cout << "=================" << m_Width << m_Height << std::endl;
	// �������
	//glClearColor(0.5f, 0.3f, 0.7f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	// ʹ��ʰȡ��ɫ��

	m_PickShader->UseProgram();
	m_PickShader->setMat4("projection", projection);
	m_PickShader->setMat4("view", view);
	m_PickShader->setMat4("model", model);

	// ����ʰȡ��ɫ
	glm::vec3 pickColor = idToColor(objetc_id);
	m_PickShader->setVec3("pickColor", pickColor);

	std::cout << "Pick color (0-255): " << (int)(pickColor.r * 255) << ", "
		<< (int)(pickColor.g * 255) << ", " << (int)(pickColor.b * 255) << std::endl;
	glBindVertexArray(m_VAO);
	glDrawElements(GL_TRIANGLES, m_Indices.size(), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);

	glFinish();

	glBindFramebuffer(GL_READ_FRAMEBUFFER, m_PickFBO);
	glReadBuffer(GL_COLOR_ATTACHMENT0);

	// ��ȡ����
	unsigned char pixel[3] = { 0, 0, 0 };
	glReadPixels(readX, readY, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel);
	// ת����ID
	int pickedID = colorToId(glm::vec3(pixel[0], pixel[1], pixel[2]));

	// �������
	std::cout << "Pixel RGB: " << (int)pixel[0] << ", " << (int)pixel[1] << ", " << (int)pixel[2] << std::endl;
	std::cout << "Picked ID: " << pickedID << " (Expected: " << objetc_id << ")" << std::endl;

	// === �ؼ�����7����ȷ�ָ�״̬ ===
	glReadBuffer(currentReadBuffer);
	glBindFramebuffer(GL_FRAMEBUFFER, currentFBO);
	glViewport(0, 0, m_Width, m_Height);

	std::cout << "========================== PICKING COMPLETE =======================" << std::endl;
}

