#include"CylinderVerticesData.h"

ModelData CylinderVerticesData::GetModelDatas()
{
	return std::make_tuple(GenerateCylinderVertices(0.8f, 2.5f, 36), GenerateCylinderIndices(36));
}

std::vector<float> CylinderVerticesData::GenerateCylinderVertices(float radius, float height, int sectors) {
	std::vector<float> vertices;

	const float PI = 3.14159265358979323846f;
	float sectorStep = 2 * PI / sectors;

	// ���ɲ��涥��
	for (int i = 0; i <= sectors; ++i)
	{
		float sectorAngle = i * sectorStep;
		float cosAngle = cos(sectorAngle);
		float sinAngle = sin(sectorAngle);

		// �ײ�����
		vertices.push_back(radius * cosAngle);      // x
		vertices.push_back(-height / 2.0f);         // y
		vertices.push_back(radius * sinAngle);      // z
		vertices.push_back(cosAngle);               // nx
		vertices.push_back(0.0f);                   // ny
		vertices.push_back(sinAngle);               // nz

		// ��������
		vertices.push_back(radius * cosAngle);      // x
		vertices.push_back(height / 2.0f);          // y
		vertices.push_back(radius * sinAngle);      // z
		vertices.push_back(cosAngle);               // nx
		vertices.push_back(0.0f);                   // ny
		vertices.push_back(sinAngle);               // nz
	}

	// ���ɶ���Բ��
	vertices.push_back(0.0f);                       // x
	vertices.push_back(height / 2.0f);              // y
	vertices.push_back(0.0f);                       // z
	vertices.push_back(0.0f);                       // nx
	vertices.push_back(1.0f);                       // ny
	vertices.push_back(0.0f);                       // nz

	for (int i = 0; i <= sectors; ++i) 
	{
		float sectorAngle = i * sectorStep;
		float cosAngle = cos(sectorAngle);
		float sinAngle = sin(sectorAngle);

		vertices.push_back(radius * cosAngle);      // x
		vertices.push_back(height / 2.0f);          // y
		vertices.push_back(radius * sinAngle);      // z
		vertices.push_back(0.0f);                   // nx
		vertices.push_back(1.0f);                   // ny
		vertices.push_back(0.0f);                   // nz
	}

	// ���ɵײ�Բ��
	vertices.push_back(0.0f);                       // x
	vertices.push_back(-height / 2.0f);             // y
	vertices.push_back(0.0f);                       // z
	vertices.push_back(0.0f);                       // nx
	vertices.push_back(-1.0f);                      // ny
	vertices.push_back(0.0f);                       // nz

	for (int i = 0; i <= sectors; ++i) 
	{
		float sectorAngle = i * sectorStep;
		float cosAngle = cos(sectorAngle);
		float sinAngle = sin(sectorAngle);

		vertices.push_back(radius * cosAngle);      // x
		vertices.push_back(-height / 2.0f);         // y
		vertices.push_back(radius * sinAngle);      // z
		vertices.push_back(0.0f);                   // nx
		vertices.push_back(-1.0f);                  // ny
		vertices.push_back(0.0f);                   // nz
	}

	return vertices;
}

std::vector<unsigned int> CylinderVerticesData::GenerateCylinderIndices(int sectors)
{
	std::vector<unsigned int> indices;

	// ���ɲ�������
	for (int i = 0; i < sectors; ++i) 
	{
		int base = i * 2;
		indices.push_back(base);
		indices.push_back(base + 1);
		indices.push_back(base + 2);

		indices.push_back(base + 1);
		indices.push_back(base + 3);
		indices.push_back(base + 2);
	}

	// ���ɶ���Բ������
	int topCenter = (sectors + 1) * 2; // ���涥������
	for (int i = 0; i < sectors; ++i) 
	{
		indices.push_back(topCenter);
		indices.push_back(topCenter + i + 1);
		indices.push_back(topCenter + i + 2);
	}

	// ���ɵײ�Բ������
	int bottomCenter = topCenter + sectors + 2; // ���� + ������������
	for (int i = 0; i < sectors; ++i) 
	{
		indices.push_back(bottomCenter);
		indices.push_back(bottomCenter + i + 2);
		indices.push_back(bottomCenter + i + 1);
	}

	return indices;
}


