#include"ToursVerticesData.h"

ModelData ToursVerticesData::GetModelDatas()
{
	return std::make_tuple(GenerateTorusVertices(1.0f, 0.4f, 32, 16), GenerateTorusIndices(32, 16));
}

//ToursVerticesData::ToursVerticesData(std::shared_ptr<Shader> shader /*= nullptr*/):
//    GraphicsEngine(shader),
//    m_bLighted(false),
//	m_RayTrack(false)
//{
//	//m_Vertices = GenerateCylinderVertices(0.8f, 2.5f, 36);
//	//m_Indices =  GenerateCylinderIndices(36);
//
//
//	m_Vertices = generateTorusVertices(1.0f, 0.4f, 32, 16);
//	m_Indices = generateTorusIndices(32, 16);
//
//
//}

std::vector<float> ToursVerticesData::GenerateCylinderVertices(float radius, float height, int sectors) {
	std::vector<float> vertices;

	const float PI = 3.14159265358979323846f;
	float sectorStep = 2 * PI / sectors;

	// ���ɲ��涥��
	for (int i = 0; i <= sectors; ++i)
	{
		float sectorAngle = i * sectorStep;
		float cosAngle = cos(sectorAngle);
		float sinAngle = sin(sectorAngle);

		// �ײ�����
		vertices.push_back(radius * cosAngle);      // x
		vertices.push_back(-height / 2.0f);         // y
		vertices.push_back(radius * sinAngle);      // z
		vertices.push_back(cosAngle);               // nx
		vertices.push_back(0.0f);                   // ny
		vertices.push_back(sinAngle);               // nz

		// ��������
		vertices.push_back(radius * cosAngle);      // x
		vertices.push_back(height / 2.0f);          // y
		vertices.push_back(radius * sinAngle);      // z
		vertices.push_back(cosAngle);               // nx
		vertices.push_back(0.0f);                   // ny
		vertices.push_back(sinAngle);               // nz
	}

	// ���ɶ���Բ��
	vertices.push_back(0.0f);                       // x
	vertices.push_back(height / 2.0f);              // y
	vertices.push_back(0.0f);                       // z
	vertices.push_back(0.0f);                       // nx
	vertices.push_back(1.0f);                       // ny
	vertices.push_back(0.0f);                       // nz

	for (int i = 0; i <= sectors; ++i) 
	{
		float sectorAngle = i * sectorStep;
		float cosAngle = cos(sectorAngle);
		float sinAngle = sin(sectorAngle);

		vertices.push_back(radius * cosAngle);      // x
		vertices.push_back(height / 2.0f);          // y
		vertices.push_back(radius * sinAngle);      // z
		vertices.push_back(0.0f);                   // nx
		vertices.push_back(1.0f);                   // ny
		vertices.push_back(0.0f);                   // nz
	}

	// ���ɵײ�Բ��
	vertices.push_back(0.0f);                       // x
	vertices.push_back(-height / 2.0f);             // y
	vertices.push_back(0.0f);                       // z
	vertices.push_back(0.0f);                       // nx
	vertices.push_back(-1.0f);                      // ny
	vertices.push_back(0.0f);                       // nz

	for (int i = 0; i <= sectors; ++i) 
	{
		float sectorAngle = i * sectorStep;
		float cosAngle = cos(sectorAngle);
		float sinAngle = sin(sectorAngle);

		vertices.push_back(radius * cosAngle);      // x
		vertices.push_back(-height / 2.0f);         // y
		vertices.push_back(radius * sinAngle);      // z
		vertices.push_back(0.0f);                   // nx
		vertices.push_back(-1.0f);                  // ny
		vertices.push_back(0.0f);                   // nz
	}

	return vertices;
}

std::vector<unsigned int> ToursVerticesData::GenerateCylinderIndices(int sectors)
{
	std::vector<unsigned int> indices;

	// ���ɲ�������
	for (int i = 0; i < sectors; ++i) 
	{
		int base = i * 2;
		indices.push_back(base);
		indices.push_back(base + 1);
		indices.push_back(base + 2);

		indices.push_back(base + 1);
		indices.push_back(base + 3);
		indices.push_back(base + 2);
	}

	// ���ɶ���Բ������
	int topCenter = (sectors + 1) * 2; // ���涥������
	for (int i = 0; i < sectors; ++i) 
	{
		indices.push_back(topCenter);
		indices.push_back(topCenter + i + 1);
		indices.push_back(topCenter + i + 2);
	}

	// ���ɵײ�Բ������
	int bottomCenter = topCenter + sectors + 2; // ���� + ������������
	for (int i = 0; i < sectors; ++i) 
	{
		indices.push_back(bottomCenter);
		indices.push_back(bottomCenter + i + 2);
		indices.push_back(bottomCenter + i + 1);
	}

	return indices;
}

// �򻯵Ķ����������ɣ�λ�úͷ��߽����洢��
std::vector<float> ToursVerticesData::GenerateTorusVertices(float majorRadius ,
	float minorRadius ,
	unsigned int majorSegments ,
	unsigned int minorSegments ) {
	std::vector<float> vertices;

	for (unsigned int i = 0; i <= majorSegments; ++i)
	{
		float majorAngle = 2.0f * 3.14159265358979323846f * i / majorSegments;
		float cosMajor = cos(majorAngle);
		float sinMajor = sin(majorAngle);

		for (unsigned int j = 0; j <= minorSegments; ++j) {
			float minorAngle = 2.0f * 3.14159265358979323846f * j / minorSegments;
			float cosMinor = cos(minorAngle);
			float sinMinor = sin(minorAngle);

			// ����λ��
			vertices.push_back((majorRadius + minorRadius * cosMinor) * cosMajor);
			vertices.push_back(minorRadius * sinMinor);
			vertices.push_back((majorRadius + minorRadius * cosMinor) * sinMajor);

			// ����
			vertices.push_back(cosMinor * cosMajor);
			vertices.push_back(sinMinor);
			vertices.push_back(cosMinor * sinMajor);
		}
	}

	return vertices;
}

// ������������
std::vector<unsigned int> ToursVerticesData::GenerateTorusIndices(unsigned int majorSegments ,
	unsigned int minorSegments ) 
{
	std::vector<unsigned int> indices;

	for (unsigned int i = 0; i < majorSegments; ++i)
	{
		for (unsigned int j = 0; j < minorSegments; ++j)
		{
			unsigned int first = i * (minorSegments + 1) + j;
			unsigned int second = (i + 1) * (minorSegments + 1) + j;

			indices.push_back(first);
			indices.push_back(second);
			indices.push_back(first + 1);

			indices.push_back(second);
			indices.push_back(second + 1);
			indices.push_back(first + 1);
		}
	}

	return indices;
}

