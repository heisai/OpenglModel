#pragma once
#include "../Graphics.h"
class CylinderVerticesData  final
{
public:
    CylinderVerticesData() = default;
    ~CylinderVerticesData() = default;
    ModelData GetModelDatas();
private:
    std::vector<float> GenerateCylinderVertices(float radius, float height, int sectors);
    std::vector<unsigned int> GenerateCylinderIndices(int sectors);
};
