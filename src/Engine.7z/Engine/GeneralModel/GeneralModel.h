#pragma once
#include"../Graphics.h"


class GeneralModel : public GraphicsEngine
{
public:
	explicit GeneralModel(std::shared_ptr<Shader> shader = nullptr);
	void Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection) override;
	void InitBufferData() override;
    void SetLightColor(glm::vec3 lightcolor);
    void SetObjectColor(glm::vec3 objectcolor);
    void DrawStencil(glm::mat4 model, glm::mat4 view, glm::mat4 projection);
    void PickModel(glm::mat4 model, glm::mat4 view, glm::mat4 projection, int xpos, int ypos, 
        int objetc_id);
    glm::vec3 idToColor(int id) {
         id = id + 1;
        float r = float((id & 0x000000FF) >> 0) / 255.0f;
        float g = float((id & 0x0000FF00) >> 8) / 255.0f;
        float b = float((id & 0x00FF0000) >> 16) / 255.0f;
        return glm::vec3(r, g, b);
    }

    int colorToId(const glm::vec3& color) {
        int r = int(color.r * 255.0f + 0.5f);
        int g = int(color.g * 255.0f + 0.5f);
        int b = int(color.b * 255.0f + 0.5f);
        int id = (b << 16) | (g << 8) | r;
        return id - 1; // ת����ԭʼID
    }
private:
    bool m_RayTrack = false;
    glm::vec3 m_ObjectColor = glm::vec3(1.0f, 0.5f, 0.31f);
    glm::vec3 m_LightColor = glm::vec3(1.0f, 1.0f, 1.0f);

   
};
