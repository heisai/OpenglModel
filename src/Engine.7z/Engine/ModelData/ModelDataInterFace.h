#pragma once

class ModelDataInterFace  
{
public:
    ModelDataInterFace() = default;
   virtual  ~ModelDataInterFace();
    ModelData GetModelDatas() = 0;
};
