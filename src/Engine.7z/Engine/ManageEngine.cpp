#include"ManageEngine.h"

ManageEngine::ManageEngine()
{

}
void ManageEngine::SetViewSize(int width, int height)
{
    m_Width = width;
    m_Height = height;
}
void ManageEngine::CreatModel(EngineType type)
{
	switch (type)
	{
	case EM_GRIDENGINE:
        CreatGridEngine();
		break;
	case EM_CUBEENGINE:
        CreatCubeEngine();
		break;
	case EM_TOURSENGINE:
        CreatToursEngine();
		break;
	case EM_MODELENGINE:
        CreatLoadModelEngine();
		break;
    case EM_CYLINDERENGINE:
        CreatCylinderEngine();
        break;
	default:
		break;
	}
}

void ManageEngine::CreatGridEngine()
{
    ShaderPtr shader = std::make_shared<Shader>("123.txt", "456.txt", "Rectangle");
    GraphicsEnginePtr graphics = std::make_shared<RectangleEngine>(shader);
    AddEngine(UUid(), graphics, shader);
}

void ManageEngine::CreatCubeEngine()
{
    ShaderPtr m_LightShader = std::make_shared<Shader>("vertex_shader.vs", "fragment_shader.fs", "LightModelEngine");
    GraphicsEnginePtr m_BasicLightEngine = std::make_shared<PhongModelEngine>(m_LightShader);
    m_BasicLightEngine->SetViewSize(this->m_Width, this->m_Height);
    AddEngine(UUid(), m_BasicLightEngine, m_LightShader);
}

void ManageEngine::CreatToursEngine()
{
	ShaderPtr m_LightShader = std::make_shared<Shader>("vertex_shader.vs", "fragment_shader.fs", "GeneralModel");
    std::unique_ptr<ToursVerticesData> vertices_data = std::make_unique<ToursVerticesData>();
	GraphicsEnginePtr m_BasicLightEngine = std::make_shared<GeneralModel>(m_LightShader);
    m_BasicLightEngine->SetModelData(vertices_data->GetModelDatas());
    m_BasicLightEngine->SetViewSize(this->m_Width, this->m_Height);
	AddEngine(UUid(), m_BasicLightEngine, m_LightShader);
}

void ManageEngine::CreatCylinderEngine()
{
	ShaderPtr m_LightShader = std::make_shared<Shader>("vertex_shader.vs", "fragment_shader.fs", "GeneralModel");
	std::unique_ptr<CylinderVerticesData> vertices_data = std::make_unique<CylinderVerticesData>();
	GraphicsEnginePtr m_BasicLightEngine = std::make_shared<GeneralModel>(m_LightShader);
	m_BasicLightEngine->SetModelData(vertices_data->GetModelDatas());
    m_BasicLightEngine->SetViewSize(this->m_Width,this->m_Height);
	AddEngine(UUid(), m_BasicLightEngine, m_LightShader);
}

void ManageEngine::CreatLoadModelEngine()
{
    ShaderPtr m_ModelShader = std::make_shared<Shader>("123.vert", "456.frag", "LoadModel");
    GraphicsEnginePtr m_LoadModelEngine = std::make_shared<LoadModelEngine>(m_ModelShader);
    AddEngine(UUid(), m_LoadModelEngine, m_ModelShader);
}





void ManageEngine::CreatMixEngine()
{
    ShaderPtr m_ModelShader = std::make_shared<Shader>("123.vert", "456.frag", "MixEngine");
    GraphicsEnginePtr m_LoadMixEngine = std::make_shared<MixEngine>(m_ModelShader);
    AddEngine(UUid(), m_LoadMixEngine, m_ModelShader);
}



void ManageEngine::AddEngine(const QString&uuid, GraphicsEnginePtr graphics,  ShaderPtr shader)
{
     if (!m_MapGraphic.count(uuid))
     {
		 glm::mat4 model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
		 glm::mat4 view = glm::mat4(1.0f);
         view = glm::translate(view, glm::vec3(0.0f, 0.0f, -10.0f));
		 glm::mat4 projection = glm::mat4(1.0f);
		 model = glm::rotate(model, glm::radians(45.0f), glm::vec3(1.0f, 1.0f, 0.0f));
         // model = glm::translate(model, glm::vec3(0.0f, 0.0f, -10.0f));
		 projection = glm::perspective(glm::radians(45.0f), (float)800 / (float)600, 0.1f, 100.0f);
         m_MapMvp[uuid] = { model ,view,projection };

         m_MapGraphic.insert(std::make_pair(uuid, graphics));
     }
     for (auto pair_vaue : m_MapGraphic)
     {
         cout << "EngineType:" << pair_vaue.first.toStdString().c_str() << endl;
     }
    
}

QString ManageEngine::UUid()
{
    QUuid id = QUuid::createUuid();
    QString strId = id.toString();
    strId.remove("{").remove("}").remove("-");
    return strId;

}

void ManageEngine::RemoveEngine(EngineType type)
{
    // if (m_MapGraphic.count(type))
    // {
    // 	m_MapGraphic.erase(type);
    // }
 //    if (type == EM_LIGHTMODELENGINE)
 //    {
 //        RemoveLightModel();
 //    }
}

void ManageEngine::CheckBoxTypeSlot(QString type, bool check)
{
	
	if (m_MapGraphic.count(type))
	{
		PhongModelEngine* engine = dynamic_cast<PhongModelEngine*>(m_MapGraphic[type].get());
		
		if (engine)
		{
			engine->m_RayTrack = check;
		}
	}
}

void ManageEngine::InitializeGL()
{
    for(auto pair: m_MapGraphic)
    {
        pair.second->m_shader->CreatProgram();
        if (pair.second->m_PickShader)
        {
            pair.second->m_PickShader->CreatProgram();
        }
        pair.second->InitBufferData();
    }
}
void ManageEngine::SetEngineScaleAndTranslate(QString uuid, glm::vec3 scale, glm::vec3 translate, glm::mat4 modelold)
{
	

//    if (m_MapMvp.count(uuid))
//    {
//#if 0
//       //  glm::mat4 model = m_MapMvp[uuid].model; // make sure to initialize matrix to identity matrix first
//        glm::mat4 model = glm::mat4(1.0);
//        glm::mat4 view = glm::mat4(1.0);
//       //  // glm::mat4 projection = m_MapMvp[uuid].projection;
//        m_MapMvp[uuid].view = glm::translate(view, glm::vec3(0.0f, 0.0f, -3.0f));
//
//        m_MapMvp[uuid].model = glm::translate(model, glm::vec3(translate.x, translate.y, translate.z));
//       //  // model = glm::scale(model, glm::vec3(scale.x, scale.y, scale.z));
//        
//       
//       //  // projection = glm::perspective(glm::radians(45.0f), (float)800 / (float)600, 0.1f, 100.0f);
//       //  m_MapMvp[uuid].model = model;
//        // m_MapMvp[uuid].projection = projection;
//#endif
//               //  glm::mat4 model = m_MapMvp[uuid].model; // make sure to initialize matrix to identity matrix first
//        
//        glm::mat4 model = glm::mat4(1.0);
//        glm::mat4 view = glm::mat4(1.0);
//        glm::mat4 projection = glm::mat4(1.0);
//        
//        model = glm::scale(model, glm::vec3(scale.x, scale.y, scale.z));
//        m_MapMvp[uuid].model = glm::translate(model, glm::vec3(translate.x, translate.y, translate.z));
//       
//
//
//        projection = glm::perspective(glm::radians(45.0f), (float)800 / (float)600, 0.1f, 100.0f);
//        m_MapMvp[uuid].view = glm::translate(view, glm::vec3(0.0f, 0.0f, -3.0f));
//        m_MapMvp[uuid].model = model* modelold;
//        m_MapMvp[uuid].projection = projection;
//    }
    int index = 0;
       for(auto onepair: m_MapMvp)
        {
            auto uuid = onepair.first;
          
            glm::mat4 model = glm::mat4(1.0);
            glm::mat4 view = glm::mat4(1.0);
            glm::mat4 projection = glm::mat4(1.0);
            projection = glm::perspective(glm::radians(45.0f), (float)800 / (float)600, 0.1f, 100.0f);
            index++;
            translate.x *= index;
            view = glm::translate(view, glm::vec3(translate.x, translate.y, translate.z));
            model = glm::scale(model, glm::vec3(scale.x, scale.y, scale.z));
            projection = glm::perspective(glm::radians(45.0f), (float)800 / (float)600, 0.1f, 100.0f);
            m_MapMvp[uuid].view = glm::translate(view, glm::vec3(0.0f, 0.0f, -3.0f));
            m_MapMvp[uuid].model = model * modelold;
            m_MapMvp[uuid].projection = projection;

          
        }
    

}

void ManageEngine::PaintGL()
{
    if (m_MapGraphic.empty())
    {
        return;
    }
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
    for(auto pair: m_MapGraphic)
    {
		pair.second->m_shader->UseProgram();
		glm::mat4 model = m_MapMvp[pair.first].model;
		glm::mat4 view = m_MapMvp[pair.first].view;
		glm::mat4 projection = m_MapMvp[pair.first].projection;
        pair.second->Draw(model,view,projection);
    }
}
void ManageEngine::PickModel(int xpos, int ypos)
{
    if (m_MapGraphic.empty())
    {
        return;
    }
    /*glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);*/
    int objetc_id = 1;
    for (auto pair : m_MapGraphic)
    {
        glm::mat4 model = m_MapMvp[pair.first].model;
        glm::mat4 view = m_MapMvp[pair.first].view;
        glm::mat4 projection = m_MapMvp[pair.first].projection;

        pair.second->PickModel(model, view, projection, xpos, ypos, objetc_id);
        objetc_id++;
        
    }
}
