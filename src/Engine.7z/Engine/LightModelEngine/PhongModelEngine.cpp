#include"PhongModelEngine.h"
PhongModelEngine::PhongModelEngine(std::shared_ptr<Shader> shader /*= nullptr*/):
    GraphicsEngine(shader),
    m_bLighted(false),
	m_RayTrack(false)
{
	//m_Stencilshader = std::make_shared<Shader>("123.vert", "456.frag", "PhongModel");

}


void PhongModelEngine::Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection)
{

	//model = glm::translate(model, glm::vec3(0.0, 2.0, 0.0));




	


	m_shader->setMat4("projection", projection);
	m_shader->setMat4("view", view);
	m_shader->setMat4("model", model);
	

	
	glStencilFunc(GL_ALWAYS, 1, 0xFF);
	glStencilMask(0xFF);
	//���ù�Դ����

	m_shader->setVec3("viewPos", view[3]);
	m_shader->setVec3("light.positiom", 1.2f, 1.0f, 2.0f);
	m_shader->setVec3("light.ambient", 0.2f, 0.2f, 0.2f);
	m_shader->setVec3("light.diffuse", 0.5f, 0.5f, 0.5f);
	m_shader->setVec3("light.specular", 1.0f, 1.0f, 1.0f);

	//���ò�������
	
	m_shader->setVec3("material.ambient", 1.2f, 1.0f, 2.0f);
	m_shader->setVec3("material.diffuse", 0.2f, 0.2f, 0.2f);
	m_shader->setVec3("material.specular", 0.5f, 0.5f, 0.5f);
	m_shader->setFloat("material.shininess", 32.0f);

	//���ö�������ָ��
	glBindVertexArray(m_VAO);
	glDrawArrays(GL_TRIANGLES, 0, 36);

	//if (m_RayTrack)
	//{
	//	DrawStencil(model, view, projection);
	//}
}

void PhongModelEngine::InitBufferData()
{
	// �����������
	glGenVertexArrays(1, &m_VAO);
	//��VAO
	glBindVertexArray(m_VAO);

	//�Ѷ������鸴�Ƶ������й�OpenGLʹ��
    glGenBuffers(1, &m_VBO);
	glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
    glBufferData(GL_ARRAY_BUFFER, m_Vertice.size() * sizeof(float), m_Vertice.data(), GL_STATIC_DRAW);
	
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
}

void PhongModelEngine::SetLightColor(glm::vec3 lightcolor)
{
	m_LightColor = lightcolor;
}

void PhongModelEngine::SetObjectColor(glm::vec3 objectcolor)
{
	m_ObjectColor = objectcolor;
}

void PhongModelEngine::DrawStencil(glm::mat4 model, glm::mat4 view, glm::mat4 projection)
{
#if 0
	
	glStencilFunc(GL_NOTEQUAL, 1, 0xFF);
	glStencilMask(0x00);
	glDisable(GL_DEPTH_TEST);
	m_Stencilshader->UseProgram();
	float scale = 1.025f;
	model = glm::scale(model, glm::vec3(scale, scale, scale));
	m_Stencilshader->setMat4("model", model);
	m_Stencilshader->setMat4("view", view);
	m_Stencilshader->setMat4("projection", projection);
	glBindVertexArray(m_VAO);
	glDrawArrays(GL_TRIANGLES, 0, 36);
	glStencilMask(0xFF);
	glStencilFunc(GL_ALWAYS, 0, 0xFF);
	glEnable(GL_DEPTH_TEST);
#endif 
}

