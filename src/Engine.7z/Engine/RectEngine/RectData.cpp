﻿#include"RectData.h"
RectangleEngine::RectangleEngine(std::shared_ptr<Shader> shader):GraphicsEngine(shader)
{
    for (int i = 0; i <= gridSize; ++i) {
        float x = -5.0f + i;

        x = i * gridSpacing - (gridSize * gridSpacing) /2;
        m_Vertice.push_back(x);

        m_Vertice.push_back(-0.5f);
         m_Vertice.push_back(- (gridSize * gridSpacing) /2);
        m_Vertice.push_back(x);

        m_Vertice.push_back(-0.5f);
         m_Vertice.push_back((gridSize * gridSpacing) /2);
    }
    for (int i = 0; i <= gridSize; ++i) {
        float z = -5.0f + i;
        z = i * gridSpacing - (gridSize * gridSpacing) /2;
        m_Vertice.push_back(- (gridSize * gridSpacing) /2);

        m_Vertice.push_back(-0.5f);
        m_Vertice.push_back(z);
        m_Vertice.push_back((gridSize * gridSpacing) /2);

        m_Vertice.push_back(-0.5f);
        m_Vertice.push_back(z);
    }
}


void RectangleEngine::Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection)
{
   
	m_shader->setMat4("model", model);
	m_shader->setMat4("view", view);
	m_shader->setMat4("projection", projection);
    // glStencilMask(0x00);
    glBindVertexArray(m_VAO);
    glLineWidth(1.0f); // 
    glDrawArrays(GL_LINES, 0,m_Vertice.size() / 3);

}

void RectangleEngine::InitBufferData()
{

#if 1
    // m_shader->CreatProgram();
    

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	// 顶点数组对象
	glGenVertexArrays(1, &m_VAO);
    glBindVertexArray(m_VAO);
    //顶点缓冲对象
	glGenBuffers(1, &m_VBO);

	//把顶点数组复制到缓冲中供OpenGL使用
	glBindBuffer(GL_ARRAY_BUFFER, m_VBO);

	glBufferData(GL_ARRAY_BUFFER, m_Vertice.size() * sizeof(float), &(m_Vertice[0]), GL_STATIC_DRAW);

    

	//设置顶点属性指针
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

#endif
}
