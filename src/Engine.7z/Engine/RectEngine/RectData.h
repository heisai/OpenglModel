﻿#ifndef RECTDATA_H
#define RECTDATA_H
#include"../Graphics.h"
class RectangleEngine : public GraphicsEngine
{
public:
    RectangleEngine(std::shared_ptr<Shader> shader = nullptr);
    void Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection) override;
    void InitBufferData() override;
    /*void CreatGraphicsData();*/

private:
    int gridSize = 50;
    int gridSize1 = 100;
    float gridSpacing = 0.25f;
    std::vector<float>m_Vertice;
    std::vector<int>m_Indices;
};
#endif // RECTDATA_H
