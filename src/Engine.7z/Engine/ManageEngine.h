#pragma once
#include"../Utils/OpengHearder.h"
#include"../Utils/Utils.h"
#include<qdebug.h>
#include <QUuid>
using GraphicsEnginePtr = std::shared_ptr<GraphicsEngine>;
using ShaderPtr = std::shared_ptr<Shader>;

struct MvpData
{
    glm::mat4 model = glm::mat4(1.0f);
    glm::mat4 view = glm::mat4(1.0f);
    glm::mat4 projection = glm::mat4(1.0f);
};
class ManageEngine:public QObject
{
public:
	ManageEngine();
    void SetViewSize(int width,int height);

    //����ģ��
    void CreatModel(EngineType type);
    //��������
    void CreatGridEngine();
    //����������
    void CreatCubeEngine();
    void CreatToursEngine();
    void CreatCylinderEngine();
    //����ģ��
    void CreatLoadModelEngine();
    // �������
    void CreatMixEngine();
    //�Ƴ�����
    void RemoveEngine(EngineType type);
    void CheckBoxTypeSlot(QString type,bool check);
    //��������
    void PaintGL();
    void PickModel(int xpos, int ypos);
    //��ʼ��
    void InitializeGL();

    void SetEngineScaleAndTranslate(QString uuid,glm::vec3 scale,glm::vec3 translate, glm::mat4 modelold);
protected:
     void AddEngine(const QString&uuid, GraphicsEnginePtr graphics, ShaderPtr shader);
    QString UUid();
public:
    std::map<QString, GraphicsEnginePtr>m_MapGraphic;
    std::map<QString, MvpData>m_MapMvp;
    int m_Width, m_Height;

};

