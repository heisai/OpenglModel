#include"ColorCubeEngine.h"

ColorCubeEngine::ColorCubeEngine(std::shared_ptr<Shader> shader):
	GraphicsEngine(shader)
{

}

void ColorCubeEngine::Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection)
{
	//���ö�������ָ��
	glBindVertexArray(m_VAO);
	glDrawArrays(GL_TRIANGLES, 0, 36);
}

void ColorCubeEngine::InitBufferData()
{
    gladLoadGL();
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	// �����������
	glGenVertexArrays(1, &m_VAO);
	//��VAO
	glBindVertexArray(m_VAO);

	//�Ѷ������鸴�Ƶ������й�OpenGLʹ��
	glGenBuffers(1, &m_VBO);
	glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
	glBufferData(GL_ARRAY_BUFFER, m_Vertice.size() * sizeof(float), &(m_Vertice[0]), GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

	glGenBuffers(1, &m_VBO_Color);
	glBindBuffer(GL_ARRAY_BUFFER, m_VBO_Color);
	glBufferData(GL_ARRAY_BUFFER, m_Vertice_Color.size() * sizeof(float), &(m_Vertice_Color[0]), GL_STATIC_DRAW);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
}
