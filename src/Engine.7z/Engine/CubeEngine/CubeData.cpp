﻿#include"CubeData.h"
CubeDataEngine::CubeDataEngine(std::shared_ptr<Shader> shader):
	GraphicsEngine(shader)
{

}
void CubeDataEngine::Draw(glm::mat4 model, glm::mat4 view, glm::mat4 projection)
{
	//设置顶点属性指针
	glDrawArrays(GL_TRIANGLES, 0, 36);

}

void CubeDataEngine::InitBufferData()
{
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	// 顶点数组对象
	glGenVertexArrays(1, &m_VAO);
	//顶点缓冲对象
	glGenBuffers(1, &m_VBO);
	//绑定VAO
	glBindVertexArray(m_VAO);
	//把顶点数组复制到缓冲中供OpenGL使用
	glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
	glBufferData(GL_ARRAY_BUFFER, m_Vertice.size() * sizeof(float), &(m_Vertice[0]), GL_STATIC_DRAW);

	//设置顶点属性指针
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);


	
}

